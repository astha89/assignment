package com.mts.entry;

import java.util.Scanner;

public interface ConversationTester {

	public Scanner getScanner();
}
