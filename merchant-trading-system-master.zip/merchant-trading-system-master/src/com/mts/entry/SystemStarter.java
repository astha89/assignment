package com.mts.entry;

public interface SystemStarter {

	public void start();


}
