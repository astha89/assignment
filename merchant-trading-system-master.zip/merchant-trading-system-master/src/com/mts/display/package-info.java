/**Packace for the logging and display purpose
 * 
 */
/**
 * @author skrishan
 *
 */
package com.mts.display;