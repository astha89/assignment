/**
 * Comodities are  things Earth persons are going to sell to aliens.
 */
/**
 * @author skrishan
 *
 */
package com.mts.system.comodity;