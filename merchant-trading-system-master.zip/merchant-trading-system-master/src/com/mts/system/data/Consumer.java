package com.mts.system.data;

/**
 * Consumer is an Entity which is a Merchant in the system. Later he can also sell things if needed.
 * @author skrishan
 *
 */
public class Consumer extends Merchant {

}
