package com.mts.system.exception;

public class MarketRateException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MarketRateException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MarketRateException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MarketRateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MarketRateException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
