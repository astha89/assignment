package com.mts.system.exception;

public class QuestionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7812678138672595513L;

	public QuestionException() {
		// TODO Auto-generated constructor stub
	}

	public QuestionException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public QuestionException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public QuestionException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
