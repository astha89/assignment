package com.mts.system.exception;

public class ImproperSymbolOrdering extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ImproperSymbolOrdering() {
		// TODO Auto-generated constructor stub
	}

	public ImproperSymbolOrdering(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ImproperSymbolOrdering(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ImproperSymbolOrdering(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
