package com.mts.system.exception;

public class AnwerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AnwerException() {
		// TODO Auto-generated constructor stub
	}

	public AnwerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AnwerException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public AnwerException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
